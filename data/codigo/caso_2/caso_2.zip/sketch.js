// =====================================
// Variables globales
// =====================================

// Clasificador preentrenado MobileNet
let classifier;

// Imagen a clasificar
let img;

// Resultados de la clasificación
let label = "clasificando...";
let confidence = "";

// Conjunto de imágenes disponibles (ruta correcta)
const images = [
  "image_classification/cheetah.png",
  "image_classification/flamingo.png",
  "image_classification/lion.png",
  "image_classification/panda.png"
];

// =====================================
// preload()
// Cargar modelo e imagen
// =====================================
function preload() {
  // Cargar clasificador MobileNet
  classifier = ml5.imageClassifier("MobileNet");

  // Seleccionar una imagen aleatoria
  const randomImage = images[Math.floor(Math.random() * images.length)];
  img = loadImage(randomImage);
}

// =====================================
// setup()
// =====================================
function setup() {
  createCanvas(400, 400);

  // Mostrar la imagen
  image(img, 0, 0, width, height);

  // Clasificar la imagen
  classifier.classify(img, gotResult);
}

// =====================================
// draw()
// =====================================
function draw() {
  // Dibujar la imagen
  image(img, 0, 0, width, height);

  // Mostrar resultados
  fill(255);
  stroke(0);
  strokeWeight(2);
  textSize(18);
  textAlign(LEFT, TOP);

  text("Etiqueta: " + label, 10, height - 50);
  text("Confianza: " + confidence, 10, height - 25);
}

// =====================================
// gotResult()
// Recibir resultados del modelo
// =====================================
function gotResult(error, results) {
  if (error) {
    console.error(error);
    label = "error";
    confidence = "";
    return;
  }

  // Guardar resultados
  label = results[0].label;
  confidence = nf(results[0].confidence, 0, 2);
}
